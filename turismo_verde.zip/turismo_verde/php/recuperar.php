<?php
// recuperar.php
header('Content-Type: text/plain; charset=utf-8');

include("../php/conexion.php"); // asume que este archivo define $conn (mysqli)

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../php/PHPMailer/src/Exception.php';
require '../php/PHPMailer/src/PHPMailer.php';
require '../php/PHPMailer/src/SMTP.php';

$correo = $_POST['correo'] ?? '';
$correo = trim($correo);

if (empty($correo)) {
    echo "error: correo vacío";
    exit;
}

// Prepared statement para evitar inyección
$stmt = $conn->prepare("
    SELECT u.nombreu, u.contrasena, p.nom1, p.apell1
    FROM usuario u
    JOIN persona p ON u.idpersona = p.idpersona
    WHERE p.correo = ? AND u.estado = 'A'
    LIMIT 1
");
if (!$stmt) {
    echo "error: prepare failed";
    exit;
}
$stmt->bind_param("s", $correo);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    // no existe
    echo "not_found";
    $stmt->close();
    $conn->close();
    exit;
}
$stmt->bind_result($nombreu, $contrasena, $nom1, $apell1);
$stmt->fetch();
$stmt->close();

// Preparar email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'turismoverde2025@gmail.com';   // <-- tu cuenta
    $mail->Password = 'pbaz mbqq xick riyu';          // <-- tu contraseña de aplicación
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom('turismoverde2025@gmail.com', 'Turismo Verde');
    $mail->addAddress($correo, "$nom1 $apell1");

    $mail->isHTML(true);
    $mail->Subject = 'Recuperación de credenciales - Turismo Verde';
    $mail->Body = "
        <h3>Recuperación de acceso - Turismo Verde</h3>
        <p>Hola <b>" . htmlspecialchars($nom1 . ' ' . $apell1) . "</b>,</p>
        <p>Solicitaste recuperar tus credenciales. Estos son tus datos:</p>
        <p><b>Usuario:</b> " . htmlspecialchars($nombreu) . "<br>
           <b>Contraseña:</b> " . htmlspecialchars($contrasena) . "</p>
        <p>Si no solicitaste este correo, ignóralo.</p>
        <hr>
        <p>Equipo Turismo Verde 🌿</p>
    ";

    $mail->send();
    echo "success";
} catch (Exception $e) {
    // Si falla el envío de correo, devolvemos la info para mostrarla al usuario (fallback)
    echo "success_with_credentials|Usuario: " . $nombreu . " | Contraseña: " . $contrasena . " | Nota: fallo al enviar correo: " . $mail->ErrorInfo;
}

$conn->close();
?>
