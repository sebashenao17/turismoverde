<?php
include("../php/conexion.php");

$usuario = $_POST["usuario"];
$contrasena = $_POST["contrasena"];

$sql = "SELECT * FROM usuario WHERE nombreu='$usuario' AND contrasena='$contrasena' AND estado='A'";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    echo "success";
} else {
    echo "error";
}

$conn->close();
?>