<?php
include("../php/conexion.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../php/PHPMailer/src/Exception.php';
require '../php/PHPMailer/src/PHPMailer.php';
require '../php/PHPMailer/src/SMTP.php';

// Recibir los datos del formulario
$nombre1 = $_POST['nom1'];
$nombre2 = $_POST['nom2'];
$apellido1 = $_POST['apell1'];
$apellido2 = $_POST['apell2'];
$direccion = $_POST['direccion'];
$telefono = $_POST['tele'];
$movil = $_POST['movil'];
$correo = $_POST['correo'];
$fecha_nac = $_POST['fecha_nac'];
$estado = 'A';

// Insertar persona
$sql_persona = "INSERT INTO persona (nom1, nom2, apell1, apell2, direccion, tele, movil, correo, fecha_nac, estado)
                VALUES ('$nombre1', '$nombre2', '$apellido1', '$apellido2', '$direccion', '$telefono', '$movil', '$correo', '$fecha_nac', '$estado')";
mysqli_query($conn, $sql_persona);

// Obtener ID de persona recién creada
$id_persona = mysqli_insert_id($conn);

// Generar usuario y contraseña aleatoria
$usuario = strtolower($nombre1) . rand(100, 999);
$contrasena = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 8);
$idperfil = 2; // Perfil Turista por defecto

// Insertar usuario
$sql_usuario = "INSERT INTO usuario (nombreu, contrasena, idperfil, idpersona, estado)
                VALUES ('$usuario', '$contrasena', '$idperfil', '$id_persona', 'A')";
mysqli_query($conn, $sql_usuario);

// Enviar correo
$mail = new PHPMailer;
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Username = 'turismoverde2025@gmail.com'; // Tu correo Gmail
$mail->Password = 'pbaz mbqq xick riyu'; // Tu contraseña de aplicación

$mail->setFrom('turismoverde2025@gmail.com', 'Turismo Verde');
$mail->addAddress($correo, $nombre1 . ' ' . $apellido1);
$mail->isHTML(true);
$mail->Subject = 'Registro en Turismo Verde';
$mail->Body = "
<h3>¡Bienvenido a Turismo Verde!</h3>
<p>Estimado <b>$nombre1 $apellido1</b>,</p>
<p>Su registro se ha realizado correctamente.</p>
<p><b>Usuario:</b> $usuario<br>
<b>Contraseña:</b> $contrasena</p>
<p>Le recomendamos cambiar su contraseña al iniciar sesión.</p>
<hr>
<p>Atentamente,<br>Equipo de Turismo Verde 🌿</p>
";

if(!$mail->send()) {
    echo 'error';
} else {
    echo 'success';
}
