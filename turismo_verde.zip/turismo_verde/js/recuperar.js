document.getElementById("formRecuperar").addEventListener("submit", async (e) => {
  e.preventDefault();
  const correo = document.getElementById("correo").value.trim();
  const msg = document.getElementById("msg");
  msg.textContent = "";

  if (!correo) {
    msg.style.color = "red";
    msg.textContent = "Ingresa un correo válido.";
    return;
  }

  try {
    const fd = new FormData();
    fd.append("correo", correo);

    const resp = await fetch("../php/recuperar.php", {
      method: "POST",
      body: fd,
    });

    const text = (await resp.text()).trim();

    if (text === "success") {
      msg.style.color = "green";
      msg.textContent = "✅ Se envió un correo con tus datos. Revisa tu bandeja.";
      setTimeout(() => window.location.href = "index.html", 2500);
    } else if (text.startsWith("success_with_credentials")) {
      // fallback cuando no se pudo enviar correo, pero se devuelve la info
      const info = text.split("|")[1] ?? "Guarda tus credenciales";
      msg.style.color = "orange";
      msg.textContent = "⚠️ " + info;
    } else if (text === "not_found") {
      msg.style.color = "red";
      msg.textContent = "❌ No existe ningún usuario con ese correo.";
    } else {
      msg.style.color = "red";
      msg.textContent = "❌ Ocurrió un error: " + text;
      console.log("recuperar.php:", text);
    }
  } catch (err) {
    console.error(err);
    msg.style.color = "red";
    msg.textContent = "⚠️ Error de conexión con el servidor.";
  }
});
