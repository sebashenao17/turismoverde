console.log("Menú cargado correctamente.");
