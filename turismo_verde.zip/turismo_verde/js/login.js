document.getElementById("formLogin").addEventListener("submit", async (e) => {
  e.preventDefault();

  const usuario = document.getElementById("usuario").value;
  const contrasena = document.getElementById("contrasena").value;

  const formData = new FormData();
  formData.append("usuario", usuario);
  formData.append("contrasena", contrasena);

  const response = await fetch("../php/login.php", {
    method: "POST",
    body: formData,
  });

  const result = await response.text();

  if (result.trim() === "success") {
    alert("✅ Bienvenido " + usuario);
    window.location.href = "menu.html";
  } else {
    alert("❌ Usuario o contraseña incorrectos");
  }
});
