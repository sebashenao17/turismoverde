function crearUsuario(){
  const usuario = prompt("Ingrese nombre de usuario:");
  const contrasena = prompt("Ingrese contraseña:");
  const idpersona = prompt("Ingrese ID de la persona asociada:");
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  const idusuario = usuarios.length + 1;
  usuarios.push({ idusuario, usuario, contrasena, idperfil: 2, idpersona, estado: "A" });
  localStorage.setItem("usuarios", JSON.stringify(usuarios));
  alert("✅ Usuario creado correctamente.");
}

function consultarUsuario(){
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  let lista = "👤 Usuarios:\n";
  usuarios.forEach(u => lista += `ID:${u.idusuario} - ${u.usuario} (${u.estado})\n`);
  alert(lista);
}

function modificarUsuario(){
  const id = prompt("Ingrese ID del usuario a modificar:");
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  const user = usuarios.find(u => u.idusuario == id);
  if(user){
    user.usuario = prompt("Nuevo nombre de usuario:", user.usuario);
    user.contrasena = prompt("Nueva contraseña:", user.contrasena);
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    alert("✅ Usuario modificado.");
  } else {
    alert("❌ Usuario no encontrado.");
  }
}

function inhabilitarUsuario(){
  const id = prompt("Ingrese ID del usuario a inhabilitar:");
  const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  const user = usuarios.find(u => u.idusuario == id);
  if(user){
    user.estado = "I";
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
    alert("🚫 Usuario inhabilitado.");
  } else {
    alert("❌ Usuario no encontrado.");
  }
}

function guardarUsuario(){
  alert("💾 Usuarios guardados correctamente (simulado).");
}
