document.getElementById("formRegistro").addEventListener("submit", async (e) => {
  e.preventDefault();

  const formData = new FormData(document.getElementById("formRegistro"));

  try {
    const response = await fetch("../php/registro.php", {
      method: "POST",
      body: formData,
    });

    const result = await response.text();

    if (result.trim() === "success") {
      alert("✅ Registro exitoso. Revise su correo 📧");
      window.location.href = "index.html"; // vuelve al login
    } else {
      alert("❌ Error al registrar la persona");
      console.log("Respuesta del servidor:", result);
    }

  } catch (error) {
    console.error("Error en la solicitud:", error);
    alert("⚠️ Error de conexión con el servidor");
  }
});
