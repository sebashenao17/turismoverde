function crearPerfil(){
  const desc = prompt("Ingrese descripción del perfil:");
  const perfiles = JSON.parse(localStorage.getItem("perfiles")) || [];
  const idperfil = perfiles.length + 1;
  perfiles.push({ idperfil, desc, estado: "A" });
  localStorage.setItem("perfiles", JSON.stringify(perfiles));
  alert("✅ Perfil creado.");
}

function consultarPerfil(){
  const perfiles = JSON.parse(localStorage.getItem("perfiles")) || [];
  let lista = "📋 Perfiles:\n";
  perfiles.forEach(p => lista += `ID:${p.idperfil} - ${p.desc} (${p.estado})\n`);
  alert(lista);
}

function modificarPerfil(){
  const id = prompt("Ingrese ID del perfil a modificar:");
  const perfiles = JSON.parse(localStorage.getItem("perfiles")) || [];
  const perfil = perfiles.find(p => p.idperfil == id);
  if(perfil){
    perfil.desc = prompt("Nueva descripción:", perfil.desc);
    localStorage.setItem("perfiles", JSON.stringify(perfiles));
    alert("✅ Perfil modificado.");
  } else {
    alert("❌ Perfil no encontrado.");
  }
}

function inhabilitarPerfil(){
  const id = prompt("Ingrese ID del perfil a inhabilitar:");
  const perfiles = JSON.parse(localStorage.getItem("perfiles")) || [];
  const perfil = perfiles.find(p => p.idperfil == id);
  if(perfil){
    perfil.estado = "I";
    localStorage.setItem("perfiles", JSON.stringify(perfiles));
    alert("🚫 Perfil inhabilitado.");
  } else {
    alert("❌ Perfil no encontrado.");
  }
}

function guardarPerfil(){
  alert("💾 Perfiles guardados (simulado).");
}
