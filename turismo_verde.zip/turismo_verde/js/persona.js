document.getElementById("formPersona").addEventListener("submit", async (e) => {
  e.preventDefault();

  const formData = new FormData();
  formData.append("nom1", document.getElementById("nom1").value);
  formData.append("nom2", document.getElementById("nom2").value);
  formData.append("apell1", document.getElementById("apell1").value);
  formData.append("apell2", document.getElementById("apell2").value);
  formData.append("direccion", document.getElementById("direccion").value);
  formData.append("tele", document.getElementById("tele").value);
  formData.append("movil", document.getElementById("movil").value);
  formData.append("correo", document.getElementById("correo").value);
  formData.append("fecha_nac", document.getElementById("fecha_nac").value);

  const response = await fetch("../php/registro.php", {
    method: "POST",
    body: formData,
  });

const result = await response.text();
if (result.trim() === "success") {
  alert("✅ Registro exitoso. Revisa tu correo.");
  window.location.href = "index.html";
} else if (result.startsWith("success_with_credentials")) {
  const info = result.split("|")[1]; // contiene Usuario: ... Contraseña: ...
  alert("✅ Registro OK. " + info + "\nNota: el envío por correo falló, guarda tus credenciales.");
  window.location.href = "index.html";
} else {
  alert("❌ " + result);
}

});
